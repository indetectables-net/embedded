
void mw_cmd_read();
void mw_cmd_write();
void mw_cmd_busy();
void mw_cmd_init();
void mw_cmd_deinit();
